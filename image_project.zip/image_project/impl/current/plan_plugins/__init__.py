# Optional plugin namespace for prompt plans.
#
# Add new modules under this package that call `image_project.impl.current.plans.register_plan(...)`
# to extend available plans without editing core orchestration.

