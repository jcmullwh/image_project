"""image_project package.

Canonical entrypoint: `python -m image_project`.
"""

