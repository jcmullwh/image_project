"""Stage catalog built from `StageRef` modules.

Stages are image-pipeline-specific macros that compile to `Block/ChatStep/ActionStep`.
"""

