from __future__ import annotations

from image_project.stages.direct.image_prompt_creation import STAGE as IMAGE_PROMPT_CREATION

__all_stages__ = [
    IMAGE_PROMPT_CREATION,
]

