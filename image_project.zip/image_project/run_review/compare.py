from __future__ import annotations

from .report_builder import diff_reports

__all__ = ["diff_reports"]
