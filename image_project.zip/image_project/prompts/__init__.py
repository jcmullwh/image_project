"""Prompt policy and parsing helpers.

Modules under `image_project.prompts` should be "pure":
- no imports from `image_project.stages`, `image_project.app`, or `image_project.impl`
- prompt builders + parsing helpers only
"""

