"""Built-in context injectors (auto-discovered by ContextManager)."""

