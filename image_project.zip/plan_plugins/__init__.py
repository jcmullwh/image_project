# Optional plugin namespace for prompt plans.
#
# Add new modules under this package that call `prompt_plans.register_plan(...)`
# to extend available plans without editing core orchestration.

